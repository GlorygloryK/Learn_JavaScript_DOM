// file: index.js

console.log("Hello from JavaScript :)");
alert("This is an alert box! Click ok to close ");


const body = document.querySelector("body"); // This identifies the body of the DOM for index.html , which previously linked via <script></script> tag


//Creating a list of groceries:
const recipeList = document.createElement("ul"); // created ordered list element
const item1 = document.createElement("li"); // create list item element 
item1.innerText = "Bannanas"; // determine the text of the list item element
recipeList.appendChild(item1); //append the list item with its content into the ul 

const item2 = document.createElement("li");
item2.innerText = "Eggs";
recipeList.appendChild(item2);

const item3 = document.createElement("li"); // create list item
item3.innerText = "Flour"; // fill it with text
recipeList.appendChild(item3); // append list item into ul 

// Now you have ul with 2 list items containing text
// Append the ul list (unordered list) into the body:

body.appendChild(recipeList);